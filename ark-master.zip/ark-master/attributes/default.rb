
default['ark']['apache_mirror'] = 'http://apache.mirrors.tds.net'
default['ark']['prefix_root'] = "/usr/local"
default['ark']['prefix_bin'] = "/usr/local/bin"
default['ark']['prefix_home'] = "/usr/local"
default['ark']['tar'] = "/bin/tar"
